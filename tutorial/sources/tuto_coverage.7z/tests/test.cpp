#include <gtest/gtest.h>
#include "math.hpp"
#include "physics.hpp"

class MathTests : public ::testing::Test {
protected:
    void SetUp() override {
    }
    void TearDown() override {
    }
};

class PhysicsTests : public ::testing::Test {
protected:
    void SetUp() override {
    }
    void TearDown() override {
    }
};

TEST_F(MathTests, Add) {
    EXPECT_EQ(math::add(2, 3), 5);
    EXPECT_EQ(math::add(-1, 1), 0);
}

TEST_F(MathTests, Sub) {
    EXPECT_EQ(math::sub(5, 3), 2);
    EXPECT_EQ(math::sub(0, 4), -4);
}

TEST_F(MathTests, Mul) {
    EXPECT_EQ(math::mul(3, 4), 12);
    EXPECT_EQ(math::mul(-2, 5), -10);
}

TEST_F(MathTests, Div) {
    EXPECT_EQ(math::div(8, 2), 4);
    EXPECT_THROW(math::div(5, 0), std::invalid_argument);
}

TEST_F(PhysicsTests, Speed) {
    EXPECT_DOUBLE_EQ(physics::speed(100, 2), 50);
    EXPECT_THROW(physics::speed(100, 0), std::invalid_argument);
}

TEST_F(PhysicsTests, KineticEnergy) {
    EXPECT_DOUBLE_EQ(physics::kinetic_energy(10, 5), 125);
}

TEST_F(PhysicsTests, GravitationalForce) {
    EXPECT_DOUBLE_EQ(physics::gravitational_force(5.972e24, 7.348e22, 3.844e8), 1.9821107290792519e+20);
    EXPECT_THROW(physics::gravitational_force(5.972e24, 7.348e22, 0), std::invalid_argument);
}

