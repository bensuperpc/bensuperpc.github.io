#include <iostream>

#include "math.hpp"
#include "physics.hpp"

int main() {
    std::cout << "2 + 3 = " << math::add(2, 3) << std::endl;
    std::cout << "5 - 2 = " << math::sub(5, 2) << std::endl;
    std::cout << "3 * 4 = " << math::mul(3, 4) << std::endl;
    std::cout << "8 / 2 = " << math::div(8, 2) << std::endl;

    try {
        std::cout << "Speed: " << physics::speed(100, 2) << " m/s" << std::endl;
        std::cout << "Kinetic Energy: " << physics::kinetic_energy(10, 5) << " J" << std::endl;
        std::cout << "Gravitational Force: " << physics::gravitational_force(5.972e24, 7.348e22, 3.844e8) << " N" << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}