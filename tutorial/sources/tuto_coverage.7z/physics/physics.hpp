#ifndef PHYSICS_HPP
#define PHYSICS_HPP

namespace physics {
    double speed(double distance, double time);
    double kinetic_energy(double mass, double velocity);
    double gravitational_force(double mass1, double mass2, double distance);
}

#endif
