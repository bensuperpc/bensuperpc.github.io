#include <iostream>
#include <cmath>

#include "physics.hpp"

namespace physics {
    constexpr double G = 6.67430e-11;

    double speed(double distance, double time) {
        if (time == 0) {
            throw std::invalid_argument("Time cannot be zero.");
        }
        return distance / time;
    }

    double kinetic_energy(double mass, double velocity) {
        return 0.5 * mass * velocity * velocity;
    }

    double gravitational_force(double mass1, double mass2, double distance) {
        if (distance == 0) {
            throw std::invalid_argument("Distance cannot be zero.");
        }
        return G * mass1 * mass2 / (distance * distance);
    }
}